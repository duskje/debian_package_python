# Example project to build a basic webapp as a deb package

To build this project you will need `poetry`. After you have it, just run

``` bash
poetry build 
```

Then, we will use `wheel2deb`.
